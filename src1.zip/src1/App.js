import React from 'react';
import Toolbar from './Toolbar';


function App() {
  return (
    <div className="App">
      <Toolbar />
    </div>
  );
}

export default App;




