import React from 'react';
import AlertButton from './AlertButton';
import './App.css';

const Toolbar = () => {
  return (
    <div>
      <AlertButton message="Hello, World!">Click me</AlertButton>
      <AlertButton message="This is another message">Another Button</AlertButton>
    </div>
  );
};

export default Toolbar;
