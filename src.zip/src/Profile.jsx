
//  Profile.js
function Profile() {
  const profileStyle = {
    textAlign: 'center',
    padding: '20px',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
  };

  const imageStyle = {
    width: '150px',
    height: '150px',
    borderRadius: '50%',
    objectFit: 'cover',
    margin: '0 auto',
  };

  return (
    <div style={profileStyle}>
      <image src="https://www.etonline.com/sites/default/files/styles/max_640x640/public/images/2023-08/ETD_SHOWCLIP_A05%20GISELE_080923_VIDPIC.jpg?h=d1cb525d" alt="Profile" style={imageStyle}/>
      <p>Hello, my name is Elida Ribeiro de Souza.</p>
    </div>
  );
}
export default Profile;
