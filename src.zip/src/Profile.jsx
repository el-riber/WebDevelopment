import React from 'react';

function Profile() {
  return (
    <div>
      <img src="https://www.etonline.com/sites/default/files/styles/max_640x640/public/images/2023-08/ETD_SHOWCLIP_A05%20GISELE_080923_VIDPIC.jpg?h=d1cb525d" alt="Profile Picture"/>
      <p>Hello, my name is Elida Ribeiro de Souza.</p>
    </div>
  );
}

export default Profile;
