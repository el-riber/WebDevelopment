// Hobbies.js
import React from 'react';
function Hobbies() {
  return (
    <div className="hobbies">
      <h2>Hobbies</h2>
      <ul>
        <li>Reading fantasy novels</li>
        <li>Traveling and exploring new cultures</li>
        <li>Playing acoustic guitar</li>
        <li>Practicing yoga and meditation</li>
        <li>Cooking Brazilian cuisine</li>
      </ul>
    </div>
  );
}

export default Hobbies;
