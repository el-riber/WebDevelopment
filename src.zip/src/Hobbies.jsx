// Hobbies.js
import React from 'react';

function Hobbies() {
  return (
    <div>
      <h2>Hobbies</h2>
      <ul>
        <li>Reading</li>
        <li>Traveling</li>
        <li>Coding</li>
        <li>Photography</li>
      </ul>
    </div>
  );
}

export default Hobbies;
