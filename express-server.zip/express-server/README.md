# Express Server

## Setup
1. Clone the repository.
2. Navigate to the project directory.
3. Install dependencies: `npm install`.

## Starting the Server
Run the following command:
node server.js

## Testing the Server
You can test the server by visiting URLs like `http://localhost:3000/user/yourname` in your browser or using tools like cURL or Postman.

## Explanation
This server uses Express.js to handle dynamic route parameters. When a request is made to `/user/:username`, the server extracts the `username` parameter from the URL and responds with a personalized message.

## Error Handling
The server includes a 404 error handler to handle requests to undefined routes.
